import Image from "next/image"
import Link from "next/link"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

interface ItemCardProps {
  id: string
  name: string
  description: string
  category: string
  imageUrl: string
  condition?: string
  size?: string
  type?: string
  uploader?: string
}

export function ItemCard({
  id,
  name,
  description,
  category,
  imageUrl,
  condition,
  size,
  type,
  uploader,
}: ItemCardProps) {
  return (
    <Card className="flex flex-col overflow-hidden">
      <div className="relative w-full h-48 bg-muted">
        <Image
          src={imageUrl || "/placeholder.svg?height=300&width=300"}
          alt={name}
          layout="fill"
          objectFit="cover"
          className="rounded-t-lg"
        />
      </div>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg line-clamp-1">{name}</CardTitle>
        <CardDescription className="line-clamp-2">{description}</CardDescription>
      </CardHeader>
      <CardContent className="text-sm text-muted-foreground flex-grow">
        <p>Category: {category}</p>
        {type && <p>Type: {type}</p>}
        {size && <p>Size: {size}</p>}
        {condition && <p>Condition: {condition}</p>}
        {uploader && <p>Uploader: {uploader}</p>}
      </CardContent>
      <CardFooter className="pt-4">
        <Link href={`/items/${id}`} className="w-full">
          <Button className="w-full">View Details</Button>
        </Link>
      </CardFooter>
    </Card>
  )
}
