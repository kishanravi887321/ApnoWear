"use client"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Shirt, ShoppingBag, User, PlusCircle, Lock, ImageIcon, Shield, LogOut } from "lucide-react"

import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarSeparator,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { useAuth } from "@/context/auth-context"

export function AppSidebar() {
  const pathname = usePathname()
  const { user, logout } = useAuth()

  const navItems = [
    {
      title: "Dashboard",
      href: "/dashboard",
      icon: Home,
      roles: ["user", "admin"],
    },
    {
      title: "My Listings",
      href: "/dashboard/my-listings",
      icon: Shirt,
      roles: ["user", "admin"],
    },
    {
      title: "My Purchases",
      href: "/dashboard/my-purchases",
      icon: ShoppingBag,
      roles: ["user", "admin"],
    },
    {
      title: "Add New Item",
      href: "/items/new",
      icon: PlusCircle,
      roles: ["user", "admin"],
    },
  ]

  const profileSettings = [
    {
      title: "Profile Details",
      href: "/dashboard/profile",
      icon: User,
      roles: ["user", "admin"],
    },
    {
      title: "Change Password",
      href: "/dashboard/profile?tab=password",
      icon: Lock,
      roles: ["user", "admin"],
    },
    {
      title: "Upload Image",
      href: "/dashboard/profile?tab=image",
      icon: ImageIcon,
      roles: ["user", "admin"],
    },
  ]

  const adminItems = [
    {
      title: "Admin Panel",
      href: "/admin",
      icon: Shield,
      roles: ["admin"],
    },
  ]

  const filteredNavItems = navItems.filter((item) => user && item.roles.includes(user.role))
  const filteredProfileSettings = profileSettings.filter((item) => user && item.roles.includes(user.role))
  const filteredAdminItems = adminItems.filter((item) => user && item.roles.includes(user.role))

  return (
    <Sidebar>
      <SidebarHeader>
        <Link href="/" className="flex items-center gap-2 p-2 text-lg font-semibold">
          <Shirt className="h-6 w-6" />
          <span>ApnoWear</span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredNavItems.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton asChild isActive={pathname === item.href}>
                    <Link href={item.href}>
                      <item.icon />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarSeparator />

        <SidebarGroup>
          <SidebarGroupLabel>Settings</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {filteredProfileSettings.map((item) => (
                <SidebarMenuItem key={item.href}>
                  <SidebarMenuButton asChild isActive={pathname === item.href.split("?")[0]}>
                    <Link href={item.href}>
                      <item.icon />
                      <span>{item.title}</span>
                    </Link>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        {filteredAdminItems.length > 0 && (
          <>
            <SidebarSeparator />
            <SidebarGroup>
              <SidebarGroupLabel>Admin</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {filteredAdminItems.map((item) => (
                    <SidebarMenuItem key={item.href}>
                      <SidebarMenuButton asChild isActive={pathname === item.href}>
                        <Link href={item.href}>
                          <item.icon />
                          <span>{item.title}</span>
                        </Link>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  ))}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </>
        )}
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <Button variant="ghost" className="w-full justify-start gap-2" onClick={logout}>
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
      <SidebarRail />
    </Sidebar>
  )
}
