"use client"

import type React from "react"

import { useState } from "react"
import { useSearchParams } from "next/navigation"
import api from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { useToast } from "@/hooks/use-toast"
import { useAuth } from "@/context/auth-context"
import { LoadingSpinner } from "@/components/loading-spinner"
import Image from "next/image"
import { User } from "lucide-react" // Declare the User variable

export default function ProfileSettingsPage() {
  const searchParams = useSearchParams()
  const defaultTab = searchParams.get("tab") || "details"
  const [activeTab, setActiveTab] = useState(defaultTab)

  const { user, updateUser, loading: authLoading } = useAuth()
  const { toast } = useToast()

  // Change Password State
  const [oldPassword, setOldPassword] = useState("")
  const [newPassword, setNewPassword] = useState("")
  const [passwordChangeLoading, setPasswordChangeLoading] = useState(false)
  const [passwordChangeError, setPasswordChangeError] = useState<string | null>(null)

  // Profile Image Upload State
  const [profileImage, setProfileImage] = useState<File | null>(null)
  const [profileImageLoading, setProfileImageLoading] = useState(false)
  const [profileImageError, setProfileImageError] = useState<string | null>(null)

  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault()
    setPasswordChangeLoading(true)
    setPasswordChangeError(null)
    try {
      await api.post("/api/users/update-password/", {
        old_password: oldPassword,
        new_password: newPassword,
      })
      toast({
        title: "Success!",
        description: "Your password has been updated.",
      })
      setOldPassword("")
      setNewPassword("")
    } catch (err: any) {
      setPasswordChangeError(err.response?.data?.detail || "Failed to change password.")
      toast({
        title: "Error",
        description: passwordChangeError || "Failed to change password.",
        variant: "destructive",
      })
      console.error("Error changing password:", err)
    } finally {
      setPasswordChangeLoading(false)
    }
  }

  const handleProfileImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setProfileImage(e.target.files[0])
    }
  }

  const handleProfileImageUpload = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!profileImage) {
      setProfileImageError("Please select an image to upload.")
      return
    }

    setProfileImageLoading(true)
    setProfileImageError(null)

    const formData = new FormData()
    formData.append("profile_image", profileImage)

    try {
      const response = await api.patch("/api/users/update-profile/", formData, {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      })
      updateUser(response.data) // Update user context with new image URL
      toast({
        title: "Success!",
        description: "Your profile picture has been updated.",
      })
      setProfileImage(null) // Clear selected file
    } catch (err: any) {
      setProfileImageError(err.response?.data?.detail || "Failed to upload profile image.")
      toast({
        title: "Error",
        description: profileImageError || "Failed to upload profile image.",
        variant: "destructive",
      })
      console.error("Error uploading profile image:", err)
    } finally {
      setProfileImageLoading(false)
    }
  }

  if (authLoading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return <p>Please log in to view your profile settings.</p>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Profile Settings</CardTitle>
          <CardDescription>Manage your account details, password, and profile picture.</CardDescription>
        </CardHeader>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="details">Details</TabsTrigger>
          <TabsTrigger value="password">Password</TabsTrigger>
          <TabsTrigger value="image">Profile Image</TabsTrigger>
        </TabsList>

        <TabsContent value="details">
          <Card>
            <CardHeader>
              <CardTitle>Your Profile</CardTitle>
              <CardDescription>View your basic profile information.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Username</Label>
                <p className="text-lg font-medium">{user.username}</p>
              </div>
              <div>
                <Label>Email</Label>
                <p className="text-lg font-medium">{user.email}</p>
              </div>
              <div>
                <Label>Role</Label>
                <p className="text-lg font-medium">{user.role}</p>
              </div>
              {user.bio && (
                <div>
                  <Label>Bio</Label>
                  <p className="text-lg font-medium">{user.bio}</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="password">
          <Card>
            <CardHeader>
              <CardTitle>Change Password</CardTitle>
              <CardDescription>Update your account password.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleChangePassword} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="old-password">Old Password</Label>
                  <Input
                    id="old-password"
                    type="password"
                    required
                    value={oldPassword}
                    onChange={(e) => setOldPassword(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-password">New Password</Label>
                  <Input
                    id="new-password"
                    type="password"
                    required
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                  />
                </div>
                {passwordChangeError && <p className="text-sm text-red-500">{passwordChangeError}</p>}
                <Button type="submit" className="w-full" disabled={passwordChangeLoading}>
                  {passwordChangeLoading ? <LoadingSpinner /> : "Change Password"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="image">
          <Card>
            <CardHeader>
              <CardTitle>Profile Image</CardTitle>
              <CardDescription>Upload a new profile picture.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleProfileImageUpload} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="profile-image">Current Profile Image</Label>
                  <div className="w-32 h-32 rounded-full overflow-hidden border border-gray-200 flex items-center justify-center">
                    {user.profile_image ? (
                      <Image
                        src={user.profile_image || "/placeholder.svg"}
                        alt="Profile"
                        width={128}
                        height={128}
                        objectFit="cover"
                      />
                    ) : (
                      <User className="h-16 w-16 text-muted-foreground" />
                    )}
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="new-profile-image">Upload New Image</Label>
                  <Input id="new-profile-image" type="file" accept="image/*" onChange={handleProfileImageChange} />
                  {profileImage && <p className="text-sm text-muted-foreground">Selected: {profileImage.name}</p>}
                </div>
                {profileImageError && <p className="text-sm text-red-500">{profileImageError}</p>}
                <Button type="submit" className="w-full" disabled={profileImageLoading}>
                  {profileImageLoading ? <LoadingSpinner /> : "Upload Image"}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
