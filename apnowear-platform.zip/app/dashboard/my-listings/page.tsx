"use client"

import { Button } from "@/components/ui/button"

import Link from "next/link"

import { useEffect, useState } from "react"
import api from "@/lib/api"
import { ItemCard } from "@/components/item-card"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LoadingSpinner } from "@/components/loading-spinner"

interface Item {
  id: string
  name: string
  description: string
  category: string
  image_url: string
  condition?: string
  size?: string
  type?: string
  // Add other fields as per your backend API response for items
}

export default function MyListingsPage() {
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchMyItems = async () => {
      try {
        setLoading(true)
        const response = await api.get("/api/items/my-items/")
        setItems(response.data)
      } catch (err: any) {
        setError(err.response?.data?.detail || "Failed to fetch your listings.")
        console.error("Error fetching my items:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchMyItems()
  }, [])

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return <div className="text-red-500 text-center">{error}</div>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>My Listings</CardTitle>
          <CardDescription>View and manage all the clothing items you have listed for exchange.</CardDescription>
        </CardHeader>
      </Card>

      {items.length === 0 ? (
        <div className="text-center text-muted-foreground p-8">
          <p>You haven't listed any items yet. Start by adding a new item!</p>
          <Link href="/items/new">
            <Button className="mt-4">List an Item</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {items.map((item) => (
            <ItemCard
              key={item.id}
              id={item.id}
              name={item.name}
              description={item.description}
              category={item.category}
              imageUrl={item.image_url}
              condition={item.condition}
              size={item.size}
              type={item.type}
            />
          ))}
        </div>
      )}
    </div>
  )
}
