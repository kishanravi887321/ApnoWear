"use client"

import { Button } from "@/components/ui/button"

import Link from "next/link"

import { useEffect, useState } from "react"
import api from "@/lib/api"
import { ItemCard } from "@/components/item-card"
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { LoadingSpinner } from "@/components/loading-spinner"

interface PurchasedItem {
  id: string
  item: {
    // Assuming the API returns nested item details
    id: string
    name: string
    description: string
    category: string
    image_url: string
    condition?: string
    size?: string
    type?: string
    uploader?: { username: string } // Assuming uploader info is nested
  }
  purchase_date: string
  // Add other fields related to the purchase/swap record
}

export default function MyPurchasesPage() {
  const [purchases, setPurchases] = useState<PurchasedItem[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchMyPurchases = async () => {
      try {
        setLoading(true)
        const response = await api.get("/api/swaps/my-purchases/")
        setPurchases(response.data)
      } catch (err: any) {
        setError(err.response?.data?.detail || "Failed to fetch your purchase history.")
        console.error("Error fetching my purchases:", err)
      } finally {
        setLoading(false)
      }
    }

    fetchMyPurchases()
  }, [])

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return <div className="text-red-500 text-center">{error}</div>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>My Purchases</CardTitle>
          <CardDescription>View all the clothing items you have acquired through swaps or points.</CardDescription>
        </CardHeader>
      </Card>

      {purchases.length === 0 ? (
        <div className="text-center text-muted-foreground p-8">
          <p>You haven't purchased or swapped any items yet. Browse available items to find your next piece!</p>
          <Link href="/dashboard">
            <Button className="mt-4">Browse Items</Button>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {purchases.map((purchase) => (
            <ItemCard
              key={purchase.id}
              id={purchase.item.id}
              name={purchase.item.name}
              description={purchase.item.description}
              category={purchase.item.category}
              imageUrl={purchase.item.image_url}
              condition={purchase.item.condition}
              size={purchase.item.size}
              type={purchase.item.type}
              uploader={purchase.item.uploader?.username}
            />
          ))}
        </div>
      )}
    </div>
  )
}
