"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { useAuth } from "@/context/auth-context"
import { DollarSign, Shirt, FlipHorizontalIcon as SwapHorizontal, User } from "lucide-react"
import { LoadingSpinner } from "@/components/loading-spinner"

export default function DashboardPage() {
  const { user, loading } = useAuth()

  if (loading) {
    return <LoadingSpinner />
  }

  if (!user) {
    return <p>Please log in to view your dashboard.</p> // Should be redirected by layout, but good fallback
  }

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Welcome</CardTitle>
          <User className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">Hello, {user.username}!</div>
          <p className="text-xs text-muted-foreground">Your role: {user.role}</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Points Balance</CardTitle>
          <DollarSign className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {/* Placeholder for points balance */}
            500
          </div>
          <p className="text-xs text-muted-foreground">Earn points by listing items.</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Total Listings</CardTitle>
          <Shirt className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">
            {/* Placeholder for total listings */}
            12
          </div>
          <p className="text-xs text-muted-foreground">View all your listed items.</p>
        </CardContent>
      </Card>
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
          <CardTitle className="text-sm font-medium">Completed Swaps</CardTitle>
          <SwapHorizontal className="h-4 w-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-2xl font-bold">{/* Placeholder for completed swaps */}5</div>
          <p className="text-xs text-muted-foreground">See your successful exchanges.</p>
        </CardContent>
      </Card>

      <div className="col-span-full">
        <Card>
          <CardHeader>
            <CardTitle>Overview</CardTitle>
            <CardDescription>Quick summary of your activity.</CardDescription>
          </CardHeader>
          <CardContent>
            <p>This section will display a summary of your uploaded items, ongoing swaps, and recent activity.</p>
            {/* More detailed overview components can go here */}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
