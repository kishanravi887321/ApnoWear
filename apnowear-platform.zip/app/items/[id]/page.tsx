"use client"

import { useEffect, useState } from "react"
import { useParams } from "next/navigation"
import Image from "next/image"
import api from "@/lib/api"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { useToast } from "@/hooks/use-toast"
import { LoadingSpinner } from "@/components/loading-spinner"

interface Item {
  id: string
  name: string
  description: string
  category: string
  type: string
  size: string
  condition: string
  tags: string
  image_url: string
  uploader: {
    id: string
    username: string
    profile_image?: string
  }
  availability_status: "available" | "swapped" | "redeemed"
  // Add other fields as per your backend API response for items
}

export default function ItemDetailPage() {
  const { id } = useParams()
  const [item, setItem] = useState<Item | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()

  useEffect(() => {
    if (id) {
      const fetchItem = async () => {
        try {
          setLoading(true)
          const response = await api.get(`/api/items/${id}/`)
          setItem(response.data)
        } catch (err: any) {
          setError(err.response?.data?.detail || "Failed to fetch item details.")
          console.error("Error fetching item:", err)
        } finally {
          setLoading(false)
        }
      }
      fetchItem()
    }
  }, [id])

  const handleSwapRequest = () => {
    // Placeholder for swap request logic
    toast({
      title: "Swap Request Sent!",
      description: "Your swap request has been sent to the uploader.",
    })
  }

  const handleRedeemViaPoints = () => {
    // Placeholder for redeem via points logic
    toast({
      title: "Redemption Initiated!",
      description: "Points deducted. Please await confirmation from the uploader.",
    })
  }

  if (loading) {
    return <LoadingSpinner />
  }

  if (error) {
    return <div className="text-red-500 text-center p-8">{error}</div>
  }

  if (!item) {
    return <div className="text-center text-muted-foreground p-8">Item not found.</div>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-3xl font-bold">{item.name}</CardTitle>
          <CardDescription>
            Category: {item.category} | Condition: {item.condition}
          </CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-8">
          <div className="relative w-full h-96 rounded-lg overflow-hidden bg-muted">
            <Image
              src={item.image_url || "/placeholder.svg?height=500&width=500"}
              alt={item.name}
              layout="fill"
              objectFit="contain"
              className="rounded-lg"
            />
          </div>
          <div className="space-y-6">
            <div>
              <h3 className="text-xl font-semibold mb-2">Description</h3>
              <p className="text-muted-foreground">{item.description}</p>
            </div>
            <Separator />
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <p className="font-medium">Type:</p>
                <p className="text-muted-foreground">{item.type}</p>
              </div>
              <div>
                <p className="font-medium">Size:</p>
                <p className="text-muted-foreground">{item.size}</p>
              </div>
              <div>
                <p className="font-medium">Tags:</p>
                <p className="text-muted-foreground">{item.tags}</p>
              </div>
              <div>
                <p className="font-medium">Availability:</p>
                <p
                  className={`font-semibold ${item.availability_status === "available" ? "text-green-600" : "text-red-600"}`}
                >
                  {item.availability_status.charAt(0).toUpperCase() + item.availability_status.slice(1)}
                </p>
              </div>
            </div>
            <Separator />
            <div className="flex items-center gap-4">
              <div className="relative w-12 h-12 rounded-full overflow-hidden border">
                <Image
                  src={item.uploader.profile_image || "/placeholder.svg?height=48&width=48"}
                  alt={item.uploader.username}
                  width={48}
                  height={48}
                  objectFit="cover"
                />
              </div>
              <div>
                <p className="font-medium">Uploader:</p>
                <p className="text-muted-foreground">{item.uploader.username}</p>
              </div>
            </div>
            <Separator />
            <div className="flex gap-4">
              <Button onClick={handleSwapRequest} disabled={item.availability_status !== "available"}>
                Swap Request
              </Button>
              <Button
                variant="outline"
                onClick={handleRedeemViaPoints}
                disabled={item.availability_status !== "available"}
              >
                Redeem via Points
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
