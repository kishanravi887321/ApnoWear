"use client"

import { useEffect, useState } from "react"
import api from "@/lib/api"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { LoadingSpinner } from "@/components/loading-spinner"
import { useAuth } from "@/context/auth-context"
import { redirect } from "next/navigation"

interface Item {
  id: string
  name: string
  description: string
  category: string
  image_url: string
  is_approved: boolean
  uploader: {
    username: string
  }
}

export default function AdminPanelPage() {
  const [items, setItems] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const { toast } = useToast()
  const { user, loading: authLoading } = useAuth()

  useEffect(() => {
    if (!authLoading && user?.role !== "admin") {
      redirect("/dashboard") // Redirect non-admins
    }
    if (user?.role === "admin") {
      fetchItemsForModeration()
    }
  }, [user, authLoading])

  const fetchItemsForModeration = async () => {
    try {
      setLoading(true)
      // Assuming an admin endpoint to get all items, or items pending approval
      const response = await api.get("/api/items/all/")
      setItems(response.data)
    } catch (err: any) {
      setError(err.response?.data?.detail || "Failed to fetch items for moderation.")
      console.error("Error fetching items for admin:", err)
    } finally {
      setLoading(false)
    }
  }

  const handleApproveReject = async (itemId: string, approve: boolean) => {
    try {
      await api.post(`/api/items/${itemId}/${approve ? "approve" : "reject"}/`)
      toast({
        title: "Success!",
        description: `Item ${approve ? "approved" : "rejected"} successfully.`,
      })
      fetchItemsForModeration() // Refresh the list
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.response?.data?.detail || `Failed to ${approve ? "approve" : "reject"} item.`,
        variant: "destructive",
      })
      console.error(`Error ${approve ? "approving" : "rejecting"} item:`, err)
    }
  }

  const handleRemoveItem = async (itemId: string) => {
    if (!confirm("Are you sure you want to remove this item?")) return
    try {
      await api.delete(`/api/items/${itemId}/`)
      toast({
        title: "Success!",
        description: "Item removed successfully.",
      })
      fetchItemsForModeration() // Refresh the list
    } catch (err: any) {
      toast({
        title: "Error",
        description: err.response?.data?.detail || "Failed to remove item.",
        variant: "destructive",
      })
      console.error("Error removing item:", err)
    }
  }

  if (authLoading || (user && user.role !== "admin" && loading)) {
    return <LoadingSpinner />
  }

  if (!user || user.role !== "admin") {
    return (
      <div className="text-red-500 text-center p-8">Access Denied. You must be an administrator to view this page.</div>
    )
  }

  if (error) {
    return <div className="text-red-500 text-center p-8">{error}</div>
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Admin Panel</CardTitle>
          <CardDescription>Moderate item listings and manage the platform.</CardDescription>
        </CardHeader>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Item Moderation</CardTitle>
          <CardDescription>Review and manage all listed clothing items.</CardDescription>
        </CardHeader>
        <CardContent>
          {items.length === 0 ? (
            <div className="text-center text-muted-foreground p-8">No items to moderate.</div>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Item Name</TableHead>
                  <TableHead>Uploader</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Approved</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {items.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{item.uploader.username}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell>{item.is_approved ? "Yes" : "No"}</TableCell>
                    <TableCell className="text-right space-x-2">
                      {!item.is_approved && (
                        <Button size="sm" variant="outline" onClick={() => handleApproveReject(item.id, true)}>
                          Approve
                        </Button>
                      )}
                      {item.is_approved && (
                        <Button size="sm" variant="outline" onClick={() => handleApproveReject(item.id, false)}>
                          Reject
                        </Button>
                      )}
                      <Button size="sm" variant="destructive" onClick={() => handleRemoveItem(item.id)}>
                        Remove
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
