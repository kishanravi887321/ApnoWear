import type React from "react"
import type { Metadata } from "next/types"
import { Inter } from "next/font/google"
import { cookies } from "next/headers"

import { AuthProvider } from "@/context/auth-context"
import { SidebarProvider } from "@/components/ui/sidebar"
import { AppSidebar } from "@/components/app-sidebar"

import "./globals.css"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ApnoWear - Community Clothing Exchange",
  description: "Exchange unused clothing and promote sustainable fashion.",
    generator: 'v0.dev'
}

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  const cookieStore = cookies()
  const defaultSidebarOpen = cookieStore.get("sidebar:state")?.value === "true"

  return (
    <html lang="en">
      <body className={inter.className}>
        <AuthProvider>
          <SidebarProvider defaultOpen={defaultSidebarOpen}>
            <AppSidebar />
            <main className="flex-1 flex flex-col min-h-screen">{children}</main>
          </SidebarProvider>
        </AuthProvider>
      </body>
    </html>
  )
}
