import Link from "next/link"
import { Card } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import {
  Search,
  Shirt,
  ShirtIcon as TShirt,
  BeanIcon as Jeans,
  SaladIcon as Dress,
  CoinsIcon as Coat,
  ShoppingBagIcon as Bag,
  FootprintsIcon as Shoe,
} from "lucide-react"
import { ItemCard } from "@/components/item-card"

// IMPORTANT: For the v0 preview to work, this URL MUST be publicly accessible.
// 'http://localhost:8000' will only work if your backend is running on the same machine
// as the Next.js app and you are running it locally.
// For v0 preview, you need to use a public URL (e.g., from ngrok or a deployed backend).
const NEXT_PUBLIC_BACKEND_URL = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000"

// Server-side data fetching for items
async function getItems() {
  const backendUrl = process.env.NEXT_PUBLIC_BACKEND_URL || "http://localhost:8000"
  try {
    const res = await fetch(`${backendUrl}/api/items/`, {
      cache: "no-store", // Ensure fresh data on each request
    })
    if (!res.ok) {
      console.error(`Failed to fetch items from ${backendUrl}/api/items/: ${res.status} ${res.statusText}`)
      const errorBody = await res.text()
      console.error("Response body:", errorBody)
      return []
    }
    return res.json()
  } catch (error: any) {
    console.error("Error fetching items on landing page:", error.message || error)
    return []
  }
}

const categories = [
  { name: "Tops", icon: TShirt, href: "#" },
  { name: "Bottoms", icon: Jeans, href: "#" },
  { name: "Dresses", icon: Dress, href: "#" },
  { name: "Outerwear", icon: Coat, href: "#" },
  { name: "Accessories", icon: Bag, href: "#" },
  { name: "Footwear", icon: Shoe, href: "#" },
]

export default async function LandingPage() {
  const items = await getItems()

  return (
    <div className="flex flex-col min-h-screen bg-peach text-gray-900">
      <header className="px-4 lg:px-6 h-16 flex items-center justify-between border-b border-apnowear-red/20 bg-apnowear-blue text-white shadow-md">
        <Link href="/" className="flex items-center gap-2 font-bold text-2xl">
          <Shirt className="h-8 w-8 text-apnowear-red" />
          <span>ApnoWear</span>
        </Link>
        <div className="relative flex-1 max-w-md mx-4">
          <Input
            type="search"
            placeholder="Search for items..."
            className="w-full pl-10 pr-4 py-2 rounded-full bg-white/20 border border-white/30 text-white placeholder:text-white/70 focus:outline-none focus:ring-2 focus:ring-white focus:border-transparent"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-white/70" />
        </div>
        <nav className="ml-auto flex gap-4 sm:gap-6">
          <Link href="/auth/login" className="text-lg font-medium hover:underline underline-offset-4">
            Login
          </Link>
          <Link href="/auth/register" className="text-lg font-medium hover:underline underline-offset-4">
            Register
          </Link>
        </nav>
      </header>

      <main className="flex-1">
        {/* Hero/Images Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-gradient-to-r from-apnowear-blue to-apnowear-red text-white">
          <div className="container px-4 md:px-6 text-center">
            <div className="space-y-4">
              <h1 className="text-4xl font-extrabold tracking-tighter sm:text-5xl md:text-6xl lg:text-7xl">
                Swap, Style, Sustain.
              </h1>
              <p className="max-w-[900px] mx-auto text-lg md:text-xl">
                Discover unique fashion, exchange unused clothing, and join the sustainable movement with ApnoWear.
              </p>
              <div className="flex flex-col gap-4 sm:flex-row justify-center pt-6">
                <Link
                  href="/auth/register"
                  className="inline-flex h-12 items-center justify-center rounded-full bg-white px-8 text-lg font-semibold text-apnowear-blue shadow-lg transition-colors hover:bg-gray-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:pointer-events-none disabled:opacity-50"
                >
                  Start Swapping
                </Link>
                <Link
                  href="/dashboard/my-listings" // Link to browse items (requires login, but for landing page, it's a CTA)
                  className="inline-flex h-12 items-center justify-center rounded-full border-2 border-white bg-transparent px-8 text-lg font-semibold text-white shadow-lg transition-colors hover:bg-white/20 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white disabled:pointer-events-none disabled:opacity-50"
                >
                  Browse Items
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-peach-100">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter text-center mb-8 sm:text-4xl">Shop by Category</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
              {categories.map((category) => (
                <Link href={category.href} key={category.name}>
                  <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-lg hover:shadow-xl transition-shadow duration-300 rounded-lg cursor-pointer">
                    <category.icon className="h-12 w-12 text-apnowear-blue mb-3" />
                    <h3 className="font-semibold text-lg">{category.name}</h3>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        </section>

        {/* Product Listings */}
        <section className="w-full py-12 md:py-24 lg:py-32 bg-apnowear-blue/10">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl font-bold tracking-tighter text-center mb-8 sm:text-4xl">Latest Listings</h2>
            {items.length === 0 ? (
              <div className="text-center text-muted-foreground p-8">
                <p>No items are currently listed. Check back soon!</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                {items.map((item: any) => (
                  <ItemCard
                    key={item.id}
                    id={item.id}
                    name={item.name}
                    description={item.description}
                    category={item.category}
                    imageUrl={item.image_url}
                    condition={item.condition}
                    size={item.size}
                    type={item.type}
                    uploader={item.uploader?.username}
                  />
                ))}
              </div>
            )}
          </div>
        </section>
      </main>

      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t border-apnowear-red/20 bg-apnowear-blue text-white">
        <p className="text-sm text-white/80">&copy; {new Date().getFullYear()} ApnoWear. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-sm hover:underline underline-offset-4">
            Terms of Service
          </Link>
          <Link href="#" className="text-sm hover:underline underline-offset-4">
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
