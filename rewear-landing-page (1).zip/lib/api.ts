// lib/api.ts
import { getAccessToken, getRefreshToken, setTokens, clearTokens } from "./auth"

const BASE_URL = "http://localhost:8000/api"

type RequestOptions = RequestInit & {
  isAuthRequired?: boolean
  isFormData?: boolean
}

export async function apiFetch<T>(endpoint: string, options: RequestOptions = {}): Promise<T> {
  const { headers, isAuthRequired = true, isFormData = false, ...rest } = options

  const url = `${BASE_URL}${endpoint}`
  let accessToken = getAccessToken()

  const requestHeaders: HeadersInit = {
    ...headers,
  }

  if (isAuthRequired && accessToken) {
    requestHeaders["Authorization"] = `Bearer ${accessToken}`
  }

  if (!isFormData) {
    requestHeaders["Content-Type"] = "application/json"
  }

  let response = await fetch(url, {
    headers: requestHeaders,
    ...rest,
  })

  // Token Refresh Logic
  if (response.status === 401 && isAuthRequired) {
    const refreshToken = getRefreshToken()
    if (refreshToken) {
      const refreshResponse = await fetch(`${BASE_URL}/users/token/refresh/`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ refresh: refreshToken }),
      })

      if (refreshResponse.ok) {
        const data = await refreshResponse.json()
        setTokens(data.access, data.refresh)
        accessToken = data.access // Update accessToken for retry

        // Retry the original request with the new token
        requestHeaders["Authorization"] = `Bearer ${accessToken}`
        response = await fetch(url, {
          headers: requestHeaders,
          ...rest,
        })
      } else {
        // Refresh token failed, clear tokens and redirect to login
        clearTokens()
        window.location.href = "/auth/login" // Client-side redirect
        throw new Error("Session expired. Please log in again.")
      }
    } else {
      // No refresh token, clear tokens and redirect to login
      clearTokens()
      window.location.href = "/auth/login" // Client-side redirect
      throw new Error("Authentication required. Please log in.")
    }
  }

  if (!response.ok) {
    const errorData = await response.json()
    throw new Error(errorData.detail || errorData.message || "An error occurred")
  }

  return response.json()
}
