// context/auth-context.tsx
"use client"

import type React from "react"
import { createContext, useContext, useState, useEffect, useCallback } from "react"
import { getAccessToken, getRefreshToken, setTokens, clearTokens } from "@/lib/auth"
import { apiFetch } from "@/lib/api"
import { useRouter } from "next/navigation"

interface AuthContextType {
  isAuthenticated: boolean
  login: (accessToken: string, refreshToken: string) => void
  logout: () => void
  loading: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [loading, setLoading] = useState(true)
  const router = useRouter()

  const checkAuth = useCallback(async () => {
    const accessToken = getAccessToken()
    const refreshToken = getRefreshToken()

    if (accessToken) {
      setIsAuthenticated(true)
    } else if (refreshToken) {
      try {
        // Attempt to refresh token if access token is missing but refresh token exists
        const data = await apiFetch("/users/token/refresh/", {
          method: "POST",
          body: JSON.stringify({ refresh: refreshToken }),
          isAuthRequired: false, // This is the refresh endpoint itself
          headers: { "Content-Type": "application/json" },
        })
        setTokens(data.access, data.refresh)
        setIsAuthenticated(true)
      } catch (error) {
        console.error("Failed to refresh token:", error)
        clearTokens()
        setIsAuthenticated(false)
      }
    } else {
      setIsAuthenticated(false)
    }
    setLoading(false)
  }, [])

  useEffect(() => {
    checkAuth()
  }, [checkAuth])

  const login = useCallback(
    (accessToken: string, refreshToken: string) => {
      setTokens(accessToken, refreshToken)
      setIsAuthenticated(true)
      router.push("/dashboard") // Redirect to dashboard after login
    },
    [router],
  )

  const logout = useCallback(() => {
    clearTokens()
    setIsAuthenticated(false)
    router.push("/auth/login") // Redirect to login after logout
  }, [router])

  return <AuthContext.Provider value={{ isAuthenticated, login, logout, loading }}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
