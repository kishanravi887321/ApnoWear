// components/shared/navbar.tsx
"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Search, Shirt } from "lucide-react"
import { useAuth } from "@/context/auth-context"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

export function Navbar() {
  const { isAuthenticated, logout } = useAuth()

  return (
    <header className="px-4 lg:px-6 h-16 flex items-center justify-between border-b-2 border-peach bg-light-blue text-light-blue-foreground shadow-md">
      <Link href="/" className="flex items-center justify-center gap-2" prefetch={false}>
        <Shirt className="h-6 w-6" />
        <span className="text-2xl font-extrabold tracking-tight">ApnoWear</span>
        <span className="sr-only">ApnoWear Home</span>
      </Link>
      <nav className="hidden md:flex gap-6">
        <Link
          href="/#how-it-works"
          className="text-base font-medium hover:text-peach transition-colors"
          prefetch={false}
        >
          How it Works
        </Link>
        <Link href="/#categories" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
          Categories
        </Link>
        <Link href="/#products" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
          Products
        </Link>
        <Link href="/#about-us" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
          About Us
        </Link>
        {isAuthenticated && (
          <>
            <Link
              href="/dashboard/create-item"
              className="text-base font-medium hover:text-peach transition-colors"
              prefetch={false}
            >
              List Item
            </Link>
            <Link
              href="/dashboard/my-listings"
              className="text-base font-medium hover:text-peach transition-colors"
              prefetch={false}
            >
              My Listings
            </Link>
            <Link
              href="/dashboard/my-purchases"
              className="text-base font-medium hover:text-peach transition-colors"
              prefetch={false}
            >
              My Purchases
            </Link>
          </>
        )}
      </nav>
      <div className="flex items-center gap-2">
        <Input
          type="search"
          placeholder="Search for clothes..."
          className="w-full max-w-xs bg-white text-foreground border-peach focus:border-light-blue"
        />
        <Button type="submit" size="icon" variant="ghost" className="hover:bg-peach/20">
          <Search className="h-5 w-5" />
          <span className="sr-only">Search</span>
        </Button>
        {isAuthenticated ? (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                <span className="sr-only">Open user menu</span>
                <div className="h-8 w-8 rounded-full bg-peach flex items-center justify-center text-peach-foreground font-bold">
                  U
                </div>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="w-56" align="end" forceMount>
              <DropdownMenuItem>
                <Link href="/dashboard/profile-settings" className="w-full">
                  Profile Settings
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem onClick={logout}>Logout</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <Link href="/auth/login" prefetch={false}>
            <Button className="bg-peach text-peach-foreground hover:bg-peach/90">Login</Button>
          </Link>
        )}
      </div>
    </header>
  )
}
