import Link from "next/link"
import Image from "next/image"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardTitle } from "@/components/ui/card"
import { Search, Shirt, Repeat, HandCoins, Sparkles, Leaf, Wallet } from "lucide-react" // Added more icons

export default function LandingPage() {
  return (
    <div className="flex flex-col min-h-screen bg-background">
      <header className="px-4 lg:px-6 h-16 flex items-center justify-between border-b-2 border-peach bg-light-blue text-light-blue-foreground shadow-md">
        <Link href="#" className="flex items-center justify-center gap-2" prefetch={false}>
          <Shirt className="h-6 w-6" />
          <span className="text-2xl font-extrabold tracking-tight">ApnoWear</span>
          <span className="sr-only">ApnoWear Home</span>
        </Link>
        <nav className="hidden md:flex gap-6">
          <Link href="#" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
            Swap
          </Link>
          <Link href="#" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
            Points
          </Link>
          <Link href="#" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
            How it Works
          </Link>
          <Link href="#" className="text-base font-medium hover:text-peach transition-colors" prefetch={false}>
            About Us
          </Link>
        </nav>
        <div className="flex items-center gap-2">
          <Input
            type="search"
            placeholder="Search for clothes..."
            className="w-full max-w-xs bg-white text-foreground border-peach focus:border-light-blue"
          />
          <Button type="submit" size="icon" variant="ghost" className="hover:bg-peach/20">
            <Search className="h-5 w-5" />
            <span className="sr-only">Search</span>
          </Button>
        </div>
      </header>
      <main className="flex-1">
        {/* Hero Section */}
        <section className="relative w-full h-[500px] md:h-[600px] lg:h-[700px] flex items-center justify-center text-center overflow-hidden">
          <Image
            src="https://source.unsplash.com/random/1600x900/?fashion-models,sustainable-clothing,diverse-people,vibrant-style"
            alt="ApnoWear Hero"
            layout="fill"
            objectFit="cover"
            quality={80}
            className="absolute inset-0 z-0"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-light-blue/70 to-peach/50 z-10 flex flex-col items-center justify-center p-6">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-white drop-shadow-lg mb-4 animate-fade-in-up">
              Your Style, Reimagined.
            </h1>
            <p className="text-lg md:text-xl lg:text-2xl text-white max-w-3xl mb-8 drop-shadow-md animate-fade-in-up delay-200">
              Swap, share, and discover unique fashion while promoting sustainability.
            </p>
            <Button className="bg-peach text-peach-foreground hover:bg-peach/90 text-lg px-8 py-3 rounded-full shadow-lg transition-transform transform hover:scale-105 animate-fade-in-up delay-400">
              Get Started Now
            </Button>
          </div>
        </section>

        {/* How It Works Section */}
        <section className="w-full py-12 md:py-20 lg:py-24 bg-peach/20">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-light-blue-foreground">
              How ApnoWear Works
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="flex flex-col items-center p-6 text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105">
                <div className="p-4 rounded-full bg-light-blue text-white mb-4">
                  <Shirt className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl font-semibold mb-2">1. List Your Clothes</CardTitle>
                <p className="text-muted-foreground">
                  Easily upload photos and details of your unused, wearable garments.
                </p>
              </Card>
              <Card className="flex flex-col items-center p-6 text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105">
                <div className="p-4 rounded-full bg-light-blue text-white mb-4">
                  <Repeat className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl font-semibold mb-2">2. Swap or Earn Points</CardTitle>
                <p className="text-muted-foreground">
                  Directly swap with others or earn points for your contributions.
                </p>
              </Card>
              <Card className="flex flex-col items-center p-6 text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105">
                <div className="p-4 rounded-full bg-light-blue text-white mb-4">
                  <HandCoins className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl font-semibold mb-2">3. Find New Styles</CardTitle>
                <p className="text-muted-foreground">
                  Redeem points or swap for exciting new additions to your wardrobe.
                </p>
              </Card>
            </div>
          </div>
        </section>

        {/* Categories Section */}
        <section className="w-full py-12 md:py-20 lg:py-24">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">Explore Categories</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-6">
              <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-md rounded-lg overflow-hidden group transition-transform hover:scale-105">
                <div className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-peach group-hover:border-light-blue transition-colors">
                  <Image
                    src="https://source.unsplash.com/random/150x150/?fashion-tops,blouse,shirt"
                    alt="Tops Category"
                    layout="fill"
                    objectFit="cover"
                    className="group-hover:scale-110 transition-transform"
                  />
                </div>
                <CardTitle className="text-lg font-semibold text-foreground">Tops</CardTitle>
              </Card>
              <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-md rounded-lg overflow-hidden group transition-transform hover:scale-105">
                <div className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-peach group-hover:border-light-blue transition-colors">
                  <Image
                    src="https://source.unsplash.com/random/150x150/?fashion-bottoms,jeans,skirt"
                    alt="Bottoms Category"
                    layout="fill"
                    objectFit="cover"
                    className="group-hover:scale-110 transition-transform"
                  />
                </div>
                <CardTitle className="text-lg font-semibold text-foreground">Bottoms</CardTitle>
              </Card>
              <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-md rounded-lg overflow-hidden group transition-transform hover:scale-105">
                <div className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-peach group-hover:border-light-blue transition-colors">
                  <Image
                    src="https://source.unsplash.com/random/150x150/?fashion-dresses,gown,sundress"
                    alt="Dresses Category"
                    layout="fill"
                    objectFit="cover"
                    className="group-hover:scale-110 transition-transform"
                  />
                </div>
                <CardTitle className="text-lg font-semibold text-foreground">Dresses</CardTitle>
              </Card>
              <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-md rounded-lg overflow-hidden group transition-transform hover:scale-105">
                <div className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-peach group-hover:border-light-blue transition-colors">
                  <Image
                    src="https://source.unsplash.com/random/150x150/?fashion-outerwear,jacket,coat"
                    alt="Outerwear Category"
                    layout="fill"
                    objectFit="cover"
                    className="group-hover:scale-110 transition-transform"
                  />
                </div>
                <CardTitle className="text-lg font-semibold text-foreground">Outerwear</CardTitle>
              </Card>
              <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-md rounded-lg overflow-hidden group transition-transform hover:scale-105">
                <div className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-peach group-hover:border-light-blue transition-colors">
                  <Image
                    src="https://source.unsplash.com/random/150x150/?fashion-accessories,jewelry,handbag,scarf"
                    alt="Accessories Category"
                    layout="fill"
                    objectFit="cover"
                    className="group-hover:scale-110 transition-transform"
                  />
                </div>
                <CardTitle className="text-lg font-semibold text-foreground">Accessories</CardTitle>
              </Card>
              <Card className="flex flex-col items-center justify-center p-4 text-center bg-white shadow-md rounded-lg overflow-hidden group transition-transform hover:scale-105">
                <div className="relative w-24 h-24 mb-4 rounded-full overflow-hidden border-2 border-peach group-hover:border-light-blue transition-colors">
                  <Image
                    src="https://source.unsplash.com/random/150x150/?fashion-footwear,shoes,sneakers,heels"
                    alt="Footwear Category"
                    layout="fill"
                    objectFit="cover"
                    className="group-hover:scale-110 transition-transform"
                  />
                </div>
                <CardTitle className="text-lg font-semibold text-foreground">Footwear</CardTitle>
              </Card>
            </div>
          </div>
        </section>

        {/* Why ApnoWear Section */}
        <section className="w-full py-12 md:py-20 lg:py-24 bg-light-blue/20">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-light-blue-foreground">
              Why Choose ApnoWear?
            </h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <Card className="flex flex-col items-center p-6 text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105">
                <div className="p-4 rounded-full bg-peach text-white mb-4">
                  <Leaf className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl font-semibold mb-2">Sustainable Fashion</CardTitle>
                <p className="text-muted-foreground">Reduce textile waste and contribute to a greener planet.</p>
              </Card>
              <Card className="flex flex-col items-center p-6 text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105">
                <div className="p-4 rounded-full bg-peach text-white mb-4">
                  <Sparkles className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl font-semibold mb-2">Discover Unique Styles</CardTitle>
                <p className="text-muted-foreground">Find one-of-a-kind pieces you won't see anywhere else.</p>
              </Card>
              <Card className="flex flex-col items-center p-6 text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105">
                <div className="p-4 rounded-full bg-peach text-white mb-4">
                  <Wallet className="h-8 w-8" />
                </div>
                <CardTitle className="text-xl font-semibold mb-2">Save Money</CardTitle>
                <p className="text-muted-foreground">Refresh your wardrobe without breaking the bank.</p>
              </Card>
            </div>
          </div>
        </section>

        {/* Product Listings */}
        <section className="w-full py-12 md:py-20 lg:py-24">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold text-center mb-12 text-foreground">Latest Listings</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-8">
              <Card className="flex flex-col overflow-hidden rounded-lg shadow-lg transition-transform hover:scale-105">
                <div className="relative w-full h-64">
                  <Image
                    src="https://source.unsplash.com/random/400x300/?stylish-denim-jacket,fashion-streetwear"
                    alt="Vintage Denim Jacket"
                    layout="fill"
                    objectFit="cover"
                    className="rounded-t-lg"
                  />
                </div>
                <CardContent className="p-4 flex-1 flex flex-col justify-between bg-white">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Vintage Denim Jacket</h3>
                    <p className="text-sm text-muted-foreground">Size: M, Condition: Good</p>
                  </div>
                  <Button className="mt-4 w-full bg-light-blue text-light-blue-foreground hover:bg-light-blue/90">
                    Swap / Redeem
                  </Button>
                </CardContent>
              </Card>
              <Card className="flex flex-col overflow-hidden rounded-lg shadow-lg transition-transform hover:scale-105">
                <div className="relative w-full h-64">
                  <Image
                    src="https://source.unsplash.com/random/400x300/?elegant-floral-dress,summer-dress"
                    alt="Floral Summer Dress"
                    layout="fill"
                    objectFit="cover"
                    className="rounded-t-lg"
                  />
                </div>
                <CardContent className="p-4 flex-1 flex flex-col justify-between bg-white">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Floral Summer Dress</h3>
                    <p className="text-sm text-muted-foreground">Size: S, Condition: Excellent</p>
                  </div>
                  <Button className="mt-4 w-full bg-light-blue text-light-blue-foreground hover:bg-light-blue/90">
                    Swap / Redeem
                  </Button>
                </CardContent>
              </Card>
              <Card className="flex flex-col overflow-hidden rounded-lg shadow-lg transition-transform hover:scale-105">
                <div className="relative w-full h-64">
                  <Image
                    src="https://source.unsplash.com/random/400x300/?mens-casual-shirt,stylish-shirt"
                    alt="Men's Casual Shirt"
                    layout="fill"
                    objectFit="cover"
                    className="rounded-t-lg"
                  />
                </div>
                <CardContent className="p-4 flex-1 flex flex-col justify-between bg-white">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">Men's Casual Shirt</h3>
                    <p className="text-sm text-muted-foreground">Size: L, Condition: New</p>
                  </div>
                  <Button className="mt-4 w-full bg-light-blue text-light-blue-foreground hover:bg-light-blue/90">
                    Swap / Redeem
                  </Button>
                </CardContent>
              </Card>
              <Card className="flex flex-col overflow-hidden rounded-lg shadow-lg transition-transform hover:scale-105">
                <div className="relative w-full h-64">
                  <Image
                    src="https://source.unsplash.com/random/400x300/?high-waisted-jeans,womens-fashion-denim"
                    alt="High-Waisted Jeans"
                    layout="fill"
                    objectFit="cover"
                    className="rounded-t-lg"
                  />
                </div>
                <CardContent className="p-4 flex-1 flex flex-col justify-between bg-white">
                  <div>
                    <h3 className="text-lg font-semibold mb-1">High-Waisted Jeans</h3>
                    <p className="text-sm text-muted-foreground">Size: 28, Condition: Good</p>
                  </div>
                  <Button className="mt-4 w-full bg-light-blue text-light-blue-foreground hover:bg-light-blue/90">
                    Swap / Redeem
                  </Button>
                </CardContent>
              </Card>
            </div>
            <div className="text-center mt-12">
              <Button className="bg-peach text-peach-foreground hover:bg-peach/90 text-lg px-8 py-3 rounded-full shadow-lg transition-transform transform hover:scale-105">
                View All Products
              </Button>
            </div>
          </div>
        </section>

        {/* Final Call to Action */}
        <section className="w-full py-12 md:py-20 lg:py-24 bg-light-blue text-white text-center">
          <div className="container px-4 md:px-6">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Ready to Refresh Your Wardrobe?</h2>
            <p className="text-lg md:text-xl max-w-2xl mx-auto mb-8">
              Join ApnoWear today and start swapping, earning, and discovering sustainable fashion!
            </p>
            <Button className="bg-peach text-peach-foreground hover:bg-peach/90 text-lg px-8 py-3 rounded-full shadow-lg transition-transform transform hover:scale-105">
              Sign Up for Free
            </Button>
          </div>
        </section>
      </main>
      <footer className="flex flex-col gap-2 sm:flex-row py-6 w-full shrink-0 items-center px-4 md:px-6 border-t-2 border-light-blue bg-peach/30 text-peach-foreground">
        <p className="text-xs text-muted-foreground">&copy; 2024 ApnoWear. All rights reserved.</p>
        <nav className="sm:ml-auto flex gap-4 sm:gap-6">
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch={false}>
            Terms of Service
          </Link>
          <Link href="#" className="text-xs hover:underline underline-offset-4" prefetch={false}>
            Privacy
          </Link>
        </nav>
      </footer>
    </div>
  )
}
