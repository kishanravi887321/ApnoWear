// app/dashboard/layout.tsx
"use client"

import type React from "react"

import { useAuth } from "@/context/auth-context"
import { useRouter } from "next/navigation"
import { useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home, PlusCircle, List, ShoppingBag, Settings } from "lucide-react"

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const { isAuthenticated, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !isAuthenticated) {
      router.push("/auth/login")
    }
  }, [isAuthenticated, loading, router])

  if (loading || !isAuthenticated) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)] bg-peach/10">
        <p className="text-lg text-light-blue-foreground">Loading dashboard...</p>
      </div>
    )
  }

  return (
    <div className="flex min-h-[calc(100vh-4rem)] bg-peach/10">
      <aside className="w-64 bg-light-blue text-light-blue-foreground p-6 shadow-lg">
        <nav className="space-y-4">
          <Link href="/dashboard" passHref>
            <Button variant="ghost" className="w-full justify-start text-lg hover:bg-peach/20 hover:text-peach">
              <Home className="mr-2 h-5 w-5" /> Dashboard
            </Button>
          </Link>
          <Link href="/dashboard/create-item" passHref>
            <Button variant="ghost" className="w-full justify-start text-lg hover:bg-peach/20 hover:text-peach">
              <PlusCircle className="mr-2 h-5 w-5" /> Create Item
            </Button>
          </Link>
          <Link href="/dashboard/my-listings" passHref>
            <Button variant="ghost" className="w-full justify-start text-lg hover:bg-peach/20 hover:text-peach">
              <List className="mr-2 h-5 w-5" /> My Listings
            </Button>
          </Link>
          <Link href="/dashboard/my-purchases" passHref>
            <Button variant="ghost" className="w-full justify-start text-lg hover:bg-peach/20 hover:text-peach">
              <ShoppingBag className="mr-2 h-5 w-5" /> My Purchases
            </Button>
          </Link>
          <Link href="/dashboard/profile-settings" passHref>
            <Button variant="ghost" className="w-full justify-start text-lg hover:bg-peach/20 hover:text-peach">
              <Settings className="mr-2 h-5 w-5" /> Profile Settings
            </Button>
          </Link>
        </nav>
      </aside>
      <main className="flex-1 p-8">{children}</main>
    </div>
  )
}
