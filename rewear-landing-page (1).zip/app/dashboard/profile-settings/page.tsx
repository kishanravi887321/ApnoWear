// app/dashboard/profile-settings/page.tsx
"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { apiFetch } from "@/lib/api"
import Image from "next/image"
import Link from "next/link"

interface UserProfile {
  username: string
  email: string
  bio?: string
  profile_image_url?: string
  // Add other profile fields as per your backend
}

export default function ProfileSettingsPage() {
  const [profile, setProfile] = useState<UserProfile | null>(null)
  const [newProfileImage, setNewProfileImage] = useState<File | null>(null)
  const [loading, setLoading] = useState(true)
  const [imageUploadLoading, setImageUploadLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        setLoading(true)
        const data = await apiFetch<UserProfile>("/users/profile/", { method: "GET" })
        setProfile(data)
      } catch (err: any) {
        setError(err.message || "Failed to fetch profile data.")
      } finally {
        setLoading(false)
      }
    }
    fetchProfile()
  }, [])

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setNewProfileImage(e.target.files[0])
    }
  }

  const handleImageUpload = async (e: React.FormEvent) => {
    e.preventDefault()
    setImageUploadLoading(true)
    setError(null)
    setSuccess(null)

    if (!newProfileImage) {
      setError("Please select an image to upload.")
      setImageUploadLoading(false)
      return
    }

    const formData = new FormData()
    formData.append("profile_image", newProfileImage) // 'profile_image' should match backend field

    try {
      const data = await apiFetch<UserProfile>("/users/update-profile/", {
        method: "POST",
        body: formData,
        isFormData: true,
      })
      setProfile(data) // Update profile with new image URL
      setSuccess("Profile image updated successfully!")
      setNewProfileImage(null) // Clear selected file
    } catch (err: any) {
      setError(err.message || "Failed to upload profile image.")
    } finally {
      setImageUploadLoading(false)
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p className="text-lg text-light-blue-foreground">Loading profile settings...</p>
      </div>
    )
  }

  if (error && !profile) {
    // Only show error if profile couldn't be loaded at all
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p className="text-lg text-destructive">{error}</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold text-light-blue-foreground">Profile Settings</h1>
      <p className="text-lg text-muted-foreground">Manage your personal information and profile picture.</p>

      <Card className="p-6 shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Profile Information</CardTitle>
          <CardDescription>View your current profile details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label>Username:</Label>
            <p className="font-medium">{profile?.username}</p>
          </div>
          <div>
            <Label>Email:</Label>
            <p className="font-medium">{profile?.email}</p>
          </div>
          <div>
            <Label>Bio:</Label>
            <p className="font-medium">{profile?.bio || "N/A"}</p>
          </div>
        </CardContent>
      </Card>

      <Card className="p-6 shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Profile Image</CardTitle>
          <CardDescription>Upload a new profile picture.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="relative h-24 w-24 rounded-full overflow-hidden border-2 border-peach">
              <Image
                src={
                  newProfileImage
                    ? URL.createObjectURL(newProfileImage)
                    : profile?.profile_image_url || "/placeholder.svg?height=96&width=96"
                }
                alt="Profile Picture"
                layout="fill"
                objectFit="cover"
              />
            </div>
            <form onSubmit={handleImageUpload} className="flex flex-col gap-2">
              <Input id="profile-image-upload" type="file" accept="image/*" onChange={handleImageChange} />
              {error && <p className="text-destructive text-sm">{error}</p>}
              {success && <p className="text-green-600 text-sm">{success}</p>}
              <Button
                type="submit"
                className="bg-light-blue text-light-blue-foreground hover:bg-light-blue/90"
                disabled={imageUploadLoading || !newProfileImage}
              >
                {imageUploadLoading ? "Uploading..." : "Upload Image"}
              </Button>
            </form>
          </div>
        </CardContent>
      </Card>

      <Card className="p-6 shadow-lg">
        <CardHeader>
          <CardTitle className="text-2xl font-semibold">Change Password</CardTitle>
          <CardDescription>
            <Link href="/auth/change-password" className="text-light-blue hover:underline" prefetch={false}>
              Click here to change your password.
            </Link>
          </CardDescription>
        </CardHeader>
      </Card>
    </div>
  )
}
