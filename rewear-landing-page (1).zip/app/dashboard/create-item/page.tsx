// app/dashboard/create-item/page.tsx
"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { apiFetch } from "@/lib/api"
import { useRouter } from "next/navigation"

export default function CreateItemPage() {
  const [name, setName] = useState("")
  const [description, setDescription] = useState("")
  const [category, setCategory] = useState("")
  const [image, setImage] = useState<File | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const [loading, setLoading] = useState(false)
  const router = useRouter()

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setImage(e.target.files[0])
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError(null)
    setSuccess(null)

    if (!image) {
      setError("Please upload an image for the item.")
      setLoading(false)
      return
    }

    const formData = new FormData()
    formData.append("name", name)
    formData.append("description", description)
    formData.append("category", category)
    formData.append("image", image) // 'image' should match the backend field name

    try {
      await apiFetch("/items/create/", {
        method: "POST",
        body: formData,
        isFormData: true, // Indicate that this is a FormData request
      })
      setSuccess("Item listed successfully!")
      setName("")
      setDescription("")
      setCategory("")
      setImage(null)
      router.push("/dashboard/my-listings")
    } catch (err: any) {
      setError(err.message || "Failed to list item. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
      <Card className="w-full max-w-2xl p-6 shadow-lg">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl font-bold text-light-blue-foreground">List a New Clothing Item</CardTitle>
          <CardDescription className="text-muted-foreground">
            Fill in the details to add your item to ApnoWear.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label htmlFor="name">Item Name</Label>
              <Input
                id="name"
                type="text"
                placeholder="e.g., Blue Denim Jacket"
                value={name}
                onChange={(e) => setName(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="Describe your item (size, condition, brand, etc.)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory} required>
                <SelectTrigger id="category">
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tops">Tops</SelectItem>
                  <SelectItem value="bottoms">Bottoms</SelectItem>
                  <SelectItem value="dresses">Dresses</SelectItem>
                  <SelectItem value="outerwear">Outerwear</SelectItem>
                  <SelectItem value="accessories">Accessories</SelectItem>
                  <SelectItem value="footwear">Footwear</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="image">Item Image</Label>
              <Input id="image" type="file" accept="image/*" onChange={handleImageChange} required />
              {image && (
                <div className="mt-4">
                  <Image
                    src={URL.createObjectURL(image) || "/placeholder.svg"}
                    alt="Selected Image Preview"
                    width={200}
                    height={200}
                    className="rounded-md object-cover"
                  />
                </div>
              )}
            </div>
            {error && <p className="text-destructive text-sm text-center">{error}</p>}
            {success && <p className="text-green-600 text-sm text-center">{success}</p>}
            <Button
              type="submit"
              className="w-full bg-light-blue text-light-blue-foreground hover:bg-light-blue/90"
              disabled={loading}
            >
              {loading ? "Listing Item..." : "List Item"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
