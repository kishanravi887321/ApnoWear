// app/dashboard/my-listings/page.tsx
"use client"

import Link from "next/link"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { apiFetch } from "@/lib/api"
import Image from "next/image"

interface Item {
  id: string
  name: string
  description: string
  category: string
  image_url: string // Assuming backend returns this
  // Add other fields as per your backend model
}

export default function MyListingsPage() {
  const [listings, setListings] = useState<Item[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchListings = async () => {
      try {
        setLoading(true)
        const data = await apiFetch<Item[]>("/items/my-items/", { method: "GET" })
        setListings(data)
      } catch (err: any) {
        setError(err.message || "Failed to fetch listings.")
      } finally {
        setLoading(false)
      }
    }
    fetchListings()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p className="text-lg text-light-blue-foreground">Loading your listings...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p className="text-lg text-destructive">{error}</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold text-light-blue-foreground">My Listings</h1>
      <p className="text-lg text-muted-foreground">Here are all the clothing items you have listed on ApnoWear.</p>

      {listings.length === 0 ? (
        <p className="text-center text-xl text-muted-foreground mt-12">
          You haven't listed any items yet.{" "}
          <Link href="/dashboard/create-item" className="text-light-blue hover:underline">
            List your first item!
          </Link>
        </p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {listings.map((item) => (
            <Card key={item.id} className="flex flex-col overflow-hidden rounded-lg shadow-lg">
              <div className="relative w-full h-64">
                <Image
                  src={item.image_url || "/placeholder.svg?height=300&width=400"} // Fallback placeholder
                  alt={item.name}
                  layout="fill"
                  objectFit="cover"
                  className="rounded-t-lg"
                />
              </div>
              <CardContent className="p-4 flex-1 flex flex-col justify-between bg-white">
                <div>
                  <h3 className="text-lg font-semibold mb-1">{item.name}</h3>
                  <p className="text-sm text-muted-foreground">{item.description}</p>
                  <p className="text-xs text-muted-foreground mt-1">Category: {item.category}</p>
                </div>
                {/* Add actions like Edit/Delete if needed */}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
