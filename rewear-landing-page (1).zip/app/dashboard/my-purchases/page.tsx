// app/dashboard/my-purchases/page.tsx
"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { apiFetch } from "@/lib/api"
import Image from "next/image"
import Link from "next/link"

interface Purchase {
  id: string
  item_name: string // Assuming backend provides this
  item_image_url: string // Assuming backend provides this
  swap_date: string // Or purchase_date
  // Add other fields as per your backend model
}

export default function MyPurchasesPage() {
  const [purchases, setPurchases] = useState<Purchase[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchPurchases = async () => {
      try {
        setLoading(true)
        const data = await apiFetch<Purchase[]>("/swaps/my-purchases/", { method: "GET" })
        setPurchases(data)
      } catch (err: any) {
        setError(err.message || "Failed to fetch purchase history.")
      } finally {
        setLoading(false)
      }
    }
    fetchPurchases()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p className="text-lg text-light-blue-foreground">Loading your purchase history...</p>
      </div>
    )
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-[calc(100vh-4rem)]">
        <p className="text-lg text-destructive">{error}</p>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold text-light-blue-foreground">My Purchase History</h1>
      <p className="text-lg text-muted-foreground">Items you have acquired through swaps or point redemption.</p>

      {purchases.length === 0 ? (
        <p className="text-center text-xl text-muted-foreground mt-12">
          You haven't made any purchases yet.{" "}
          <Link href="/" className="text-light-blue hover:underline">
            Browse items!
          </Link>
        </p>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {purchases.map((purchase) => (
            <Card key={purchase.id} className="flex flex-col overflow-hidden rounded-lg shadow-lg">
              <div className="relative w-full h-64">
                <Image
                  src={purchase.item_image_url || "/placeholder.svg?height=300&width=400"} // Fallback placeholder
                  alt={purchase.item_name}
                  layout="fill"
                  objectFit="cover"
                  className="rounded-t-lg"
                />
              </div>
              <CardContent className="p-4 flex-1 flex flex-col justify-between bg-white">
                <div>
                  <h3 className="text-lg font-semibold mb-1">{purchase.item_name}</h3>
                  <p className="text-sm text-muted-foreground">
                    Acquired on: {new Date(purchase.swap_date).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
