// app/dashboard/page.tsx
import { Card, CardDescription, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { PlusCircle, List, ShoppingBag, Settings } from "lucide-react"

export default function DashboardPage() {
  return (
    <div className="space-y-8">
      <h1 className="text-4xl font-bold text-light-blue-foreground">Welcome to Your ApnoWear Dashboard!</h1>
      <p className="text-lg text-muted-foreground">Manage your listings, track your swaps, and update your profile.</p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <Link href="/dashboard/create-item" passHref>
          <Card className="p-6 flex flex-col items-center text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105 cursor-pointer">
            <PlusCircle className="h-12 w-12 text-light-blue mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">List a New Item</CardTitle>
            <CardDescription>Add a new clothing item to your collection for swapping or points.</CardDescription>
          </Card>
        </Link>
        <Link href="/dashboard/my-listings" passHref>
          <Card className="p-6 flex flex-col items-center text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105 cursor-pointer">
            <List className="h-12 w-12 text-light-blue mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">My Listings</CardTitle>
            <CardDescription>View and manage all the clothing items you have listed.</CardDescription>
          </Card>
        </Link>
        <Link href="/dashboard/my-purchases" passHref>
          <Card className="p-6 flex flex-col items-center text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105 cursor-pointer">
            <ShoppingBag className="h-12 w-12 text-light-blue mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">My Purchases</CardTitle>
            <CardDescription>See the history of items you've acquired through swaps or points.</CardDescription>
          </Card>
        </Link>
        <Link href="/dashboard/profile-settings" passHref>
          <Card className="p-6 flex flex-col items-center text-center bg-white shadow-lg rounded-lg transition-transform hover:scale-105 cursor-pointer">
            <Settings className="h-12 w-12 text-light-blue mb-4" />
            <CardTitle className="text-xl font-semibold mb-2">Profile Settings</CardTitle>
            <CardDescription>Update your profile information and change your password.</CardDescription>
          </Card>
        </Link>
      </div>
    </div>
  )
}
