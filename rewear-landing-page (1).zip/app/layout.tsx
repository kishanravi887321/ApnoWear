import type React from "react"
import type { Metadata } from "next/types"
import { Inter } from "next/font/google"
import "./globals.css"
import { AuthProvider } from "@/context/auth-context"
import { Navbar } from "@/components/shared/navbar"
import { ThemeProvider } from "@/components/theme-provider" // Assuming this is already available

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "ApnoWear - Sustainable Fashion Exchange",
  description: "Exchange unused clothing through direct swaps or a point-based redemption system.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <AuthProvider>
            <Navbar />
            {children}
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}
